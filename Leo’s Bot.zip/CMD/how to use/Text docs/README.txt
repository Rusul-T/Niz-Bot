1. Install Node.js: https://nodejs.org/en/ (Click "Recommended For Most Users" button to download)
2. Open CMD in the "bot" folder (01.png)
3. Type "npm install" and hit Enter
4. Rename "config.json.sample" to "config.json" and "trade.json.sample" to "trade.json"
5. Open config file and type in your API key and secret key (02.png) **Warning: Bittrex has just restricted the use of bots lately so I have to make it to scan slower than  before. Therefore, you should run this bot on Binance or on both Binance and Bittrex by duplicating it
6. Find your telegram user id by using @JsonDumpBot (03.png)
7. Go to Telegram and find @heroicteambot -> tap /start (in order to allow messages from the bot to send to you)
8. Type "node app.js" (04.png) and hit Enter
------------------------------------------------
To start the bot: Type node app.js -> hit enter
To stop the bot: Press Ctrl + C
